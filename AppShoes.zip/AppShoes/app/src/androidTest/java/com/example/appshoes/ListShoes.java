package com.example.appshoes;

import static org.junit.Assert.*;

public class ListShoes {

}