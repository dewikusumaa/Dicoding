package com.example.appshoes;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class DetailShoes extends AppCompatActivity {
    public static final String EXTRA_FULLNAME = "extra_fullname";
    public static final String EXTRA_HARGA= "extra_harga";
    public static final String EXTRA_DETAIL= "extra_detail";
    public static final String EXTRA_IMG= "extra_img";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        ImageView imgShoes;
        TextView tvFullName, tvHarga, tvDetail;

        super.onCreate(savedInstanceState);
        setContentView(R.layout.detail_shoes);
        imgShoes = findViewById(R.id.tv_shoes_photo);
        tvFullName = findViewById(R.id.tv_full_name);
        tvHarga = findViewById(R.id.tv_harga);
        tvDetail = findViewById(R.id.tv_detail);

        String full = getIntent().getStringExtra(EXTRA_FULLNAME),
                harga = getIntent().getStringExtra(EXTRA_HARGA),
                detail = getIntent().getStringExtra(EXTRA_DETAIL);
        int photo = getIntent().getIntExtra(EXTRA_IMG,0);
        Bitmap bmp = BitmapFactory.decodeResource(getResources(), photo);
        imgShoes.setImageBitmap(bmp);
        tvFullName.setText(full);
        tvHarga.setText(harga);
        tvDetail.setText(detail);
    }
}
