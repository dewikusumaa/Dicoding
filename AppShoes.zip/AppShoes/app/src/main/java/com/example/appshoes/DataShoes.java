package com.example.appshoes;

import java.util.ArrayList;

public class DataShoes {
    private static String[] shoesFullName = {
            "Nike Zoom Freak 1",
            "Adidas Harden Vol.3",
            "Air Jordan 12 High",
            "Nike Kobe AD NXT FF",
            "Nike Lebron 17",
            "Underarmour Curry 6 High",
            "Adidas Drose 10",
            "Adidas Harden 4",
            "Nike KD 12",
            "Air Jordan Why Not Zero.2"

    };

    private static String[] shoesHarga = {
            "Rp. 690.000",
            "Rp. 670.000",
            "Rp. 570.000",
            "Rp. 670.000",
            "Rp. 700.000",
            "Rp. 700.000",
            "Rp. 650.000",
            "Rp. 670.000",
            "Rp. 680.000",
            "Rp. 700.000"
    };

    private static String[] shoesDetail = {
            "Nike Zoom Freak 1, Premium Quality, Size: 40-46, Cara Pemesanan: Wa: 082135487713",
            "Adidas Harden Vol.3, Premium Quality, Size: 40-46, Cara Pemesanan: Wa: 082135487713",
            "Air Jordan 12 High, Premium Quality, Size: 40-46, Cara Pemesanan: Wa: 082135487713",
            "Nike Kobe AD NXT FF, Premium Quality, Size: 40-46, Cara Pemesanan: Wa: 082135487713",
            "Nike Lebron 17, Premium Quality, Size: 40-46, Cara Pemesanan: Wa: 082135487713",
            "Underarmour Curry 6 High, Premium Quality, Size: 40-46, Cara Pemesanan: Wa: 082135487713",
            "Adidas Drose 10, Premium Quality, Size: 40-46, Cara Pemesanan: Wa: 082135487713",
            "Adidas Harden 4, Premium Quality, Size: 40-46, Cara Pemesanan: Wa: 082135487713",
            "Nike KD 12, Premium Quality, Size: 40-46, Cara Pemesanan: Wa: 082135487713",
            "Air Jordan Why Not Zero.2, Premium Quality, Size: 40-46, Cara Pemesanan: Wa: 082135487713"
    };

    private static int[] photo = {
            R.drawable.giannis,
            R.drawable.adidas,
            R.drawable.jordan,
            R.drawable.kobe,
            R.drawable.lebron,
            R.drawable.underarmor,
            R.drawable.drose,
            R.drawable.harden,
            R.drawable.kd,
            R.drawable.why
    };

    static ArrayList<ShoesArchitecture> getListData() {
        ArrayList<ShoesArchitecture> list = new ArrayList<>();
        for (int position = 0; position < shoesHarga.length; position++) {
            ShoesArchitecture nw = new ShoesArchitecture();
            nw.setFullName(shoesFullName[position]);
            nw.setHarga(shoesHarga[position]);
            nw.setDetail(shoesDetail[position]);
            nw.setPhoto(photo[position]);
            list.add(nw);
        }

        return list;
    }
}
