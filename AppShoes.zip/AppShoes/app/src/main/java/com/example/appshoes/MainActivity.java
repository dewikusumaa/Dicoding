package com.example.appshoes;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rvShoes;
    private ArrayList<ShoesArchitecture> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        rvShoes = findViewById(R.id.rv_shoes);
        rvShoes.setHasFixedSize(true);

        list.addAll(DataShoes.getListData());

        showRecyclerList();
    }
    private void showRecyclerList() {
        rvShoes.setLayoutManager(new LinearLayoutManager(this));
        ListShoes listShoes = new ListShoes(list);
        rvShoes.setAdapter(listShoes);

        listShoes.setOnItemClickCallback(new ListShoes.OnItemClickCallback() {
            @Override
            public void onItemClicked(ShoesArchitecture data) {

                showSelectedData(data);
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        Intent about = new Intent(MainActivity.this, datadiri.class);
        startActivity(about);
        return super.onOptionsItemSelected(item);
    }

    public void showSelectedData(ShoesArchitecture nw) {
        Intent detailIntent = new Intent(MainActivity.this, DetailShoes.class);
        detailIntent.putExtra(DetailShoes.EXTRA_IMG, nw.getPhoto());
        detailIntent.putExtra(DetailShoes.EXTRA_FULLNAME, nw.getFullName());
        detailIntent.putExtra(DetailShoes.EXTRA_HARGA, nw.getHarga());
        detailIntent.putExtra(DetailShoes.EXTRA_DETAIL, nw.getDetail());
        startActivity(detailIntent);
    }
}
