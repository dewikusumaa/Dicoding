package com.example.appshoes;

public class ShoesArchitecture {
    private String fullName;
    private String harga;
    private String detail;
    private int photo;


    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String detail) { this.harga = detail; }

    public String getDetail() {
        return detail;
    }

    public void setDetail(String lahir) {
        this.detail = lahir;
    }

    public int getPhoto() {
        return photo;
    }

    public void setPhoto(int photo) {
        this.photo = photo;
    }
}
